	$(document).on('click','.createComment',function(){
	let userId = $(this).attr('data-user');
	let post = $(this).attr('data-post');
	let comments =$.parseJSON($(this).attr('data-comment'));
	if(comments.length>0) {
		$('.showComment').html('');
		comments.map((item)=>{
			$('.showComment').append('<div class="row"><div class="col-sm-12"><p><b><i class="fa fa-user"></i> '+item.username+'</b></p><p>'+item.comment+'</p></div></div><hr>');
		})
	} else {
		$('.showComment').html('<p>Comment Not Found</p>');
	} 
	$('#user_id').val(userId);
	$('#post_id').val(post);
	$('#commentPopup').modal('show');

});
$(document).on('click','#submitComment',function(){
	var userId = $('#user_id').val();
	var postId = $('#post_id').val();
	var comment = $('#commentField').val();
	if(comment=='') {
		alert('Please Enter Comment');
	} else {
		$.post(base_url+'home/createComment',{'user_id':userId,'post_id':postId,'comment':comment},function(fb){
			alert('Post Successfully Created');
			window.location.reload();
		})
	}
	
});

