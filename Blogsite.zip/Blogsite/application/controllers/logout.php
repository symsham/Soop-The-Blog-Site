<?php

class Logout extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->library('session');
    }

    public function index() {
        // Destroy the session
        $this->session->sess_destroy('users');
        <?php
    session_start();
    
    unset($_SESSION['login']);
    unset($_SESSION['name']);
    session_destroy();
    header('Location:home/login');
    exit();
?>

    }

}