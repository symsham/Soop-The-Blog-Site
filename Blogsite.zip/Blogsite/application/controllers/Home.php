66r4<?php

Class Home extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();

	}
	public function index()
	{
		$this->db->order_by('post.id','desc');
		$this->db->join('users','post.user_id=users.id');
		$data['post'] = $this->CM->select_data('post','post.*,users.name as username');
        $this->load->view('include/header');
        $this->load->view('home',$data);
        $this->load->view('include/footer');
        

        	}
public function search_result(){

	$users=$this->CM->likeQuery('users',array('name'=>$this->input->post('search')));
	$data['users']='$users';
	$this->load->view('include/header');
        $this->load->view('more_users',$data);
        $this->load->view('include/footer'); 
}
public function createNewPost(){
		$data = $this->input->post();
		if(isset($data['text_post']))
		{
			if($data['text_post']!='')
			{
				echo $this->CM->insert_data('post',array('text_post'=>$data['text_post'],'user_id'=>$this->session->userdata('userinfo')[0]['id'],'status'=>'0'));		
			}
		}
		$this->session->set_flashdata('success_message','Post Successfully Created');
		redirect(base_url(''));
	}
	public function share_post($id) {
		$postInfo = $this->CM->select_data('post','*',array('id'=>$id));
		$arr  = array(
			'text_post'=>$postInfo[0]['text_post'],
			'user_id'=>$this->session->userdata('userinfo')[0]['id'],
			'status'=>1,
			'parent_user'=>$postInfo[0]['user_id'],
		);
		$this->CM->insert_data('post',$arr);
		$this->session->set_flashdata('success_message','Post Successfully Shared');
		redirect(base_url(''));
	}
	public function follow_request(){
		if($this->session->userdata('userinfo')) {
			$this->db->join('users','follow_user.user2=users.id');
			$this->db->order_by('follow_user.id','desc');
			$data['follow_users'] = $this->CM->select_data('follow_user','follow_user.*,users.name,users.city',array('user1'=>$this->session->userdata('userinfo')[0]['id']));
			$this->load->view('include/header');
			$this->load->view('follow_request',$data);
			$this->load->view('include/footer');	
		} else {
			redirect(base_url('home/login'));
		}
	}
	public function approve_request($id){
		$info=$this->CM->select_data('follow_user','*',array('id'=>$id));

		$this->CM->update_data('follow_user',array('status'=>'1'),array('id'=>$id));
		$this->CM->insert_data('userconnection',array('token '=>$info[0]['user1']. 'CHAT'.$info[0]['user2'],'user_id'=>$info[0]['user1'], 'user_id2'=>$info[0]['user2'])); 
		$this->CM->insert_data('userconnection',array('token '=>$info[0]['user2']. 'CHAT' .$info[0]['user1'],'user_id'=>$info[0]['user2'],  'user_id2'=>$info[0]['user1']));
		redirect(base_url('home/follow_request'));
	}
	public function delete_request($id){
		$this->CM->delete_data('follow_user',array('id'=>$id));
		redirect(base_url('home/follow_request'));
	}
	public function post_like($user_id,$post_id){
		$isExists = $this->CM->select_data('post_like','id',array('user_id'=>$user_id,'post_id'=>$post_id));
		if($isExists) {
			$this->CM->delete_data('post_like',array('id'=>$isExists[0]['id']));
			$this->session->set_flashdata('success_message','Post Successfully Unlike');
		} else {
			echo $this->CM->insert_data('post_like',array('user_id'=>$user_id,'post_id'=>$post_id));
			$this->session->set_flashdata('success_message','Post Successfully Like');
		}
		redirect(base_url());
		
	}
	public function createComment(){
		$data = $this->input->post();
		echo $this->CM->insert_data('post_comment',$data);
	}
	public function chat(){
		$this->db->join('users','userconnection.user_id2=users.id');
		$data['chatToken']=$this->CM->select_data('userconnection','userconnection.*,users.name as username',array('userconnection.user_id'=>$this->session->userdata('userinfo')[0]['id']));
		$this->load->view('include/header');
			$this->load->view('chat',$data);
			$this->load->view('include/footer');
	}
	public function notify(){
		    $this->load->view('include/header');
			$this->load->view('notify');
			$this->load->view('include/footer');
	}
	public function more_users()
	{
		if($this->session->userdata('userinfo')) {
		$data['users'] = $this->CM->select_data('users','*');
		$this->load->view('include/header');
		$this->load->view('more_users',$data);
		$this->load->view('include/footer');	
		} else {
			redirect(base_url('home/login'));
		}
	}
	public function follow_user($id){
		$this->CM->insert_data('follow_user',array('user1'=>$id,'user2'=>$this->session->userdata('userinfo')[0]['id']));
		$this->session->set_flashdata('success_message','Follow Request Successfully Send');
		redirect(base_url());
	}
	public function login()
	{
		if($this->input->method()=='post'){
			$user = $this->CM->select_data('users','*',array('email'=>$this->input->post('name'),'password'=>$this->input->post('password')));
			if($user) {
				$this->session->set_userdata('userinfo',$user);
				redirect(base_url(''));
			} else {
				$this->session->set_flashdata('email_error','UserName And Password Not Match');
				redirect(base_url('home/login'));
			}

		} else { 
			if($this->session->userdata('userinfo')) {
				redirect(base_url(''));
			} else {
				$this->load->view('include/header');
				$this->load->view('auth/login');
				$this->load->view('include/footer');	
			}
			
		}
	}
	
	public function logout_view()
	{
	if($this->session->sess_destroy('users'));{
	redirect(base_url('home/login'));
}
			}

	  
	public function signUp()
	{
		if($this->input->method()=='post')
		{
			$data=$this->input->post();
			$isExists = $this->CM->select_data('users','*',array('email'=>$data['email']));
			if(count($isExists)>0) {
				$this->session->set_flashdata('email_error','This E-Mail Already Exists');
				redirect('home/signUp');
			}
			else 
			{
				$resp = $this->CM->insert_data('users',$_POST);
				if($resp) {
					$this->session->set_flashdata('success','Account Successfully Created');
					redirect('home/login');
				} else {
					$this->session->set_flashdata('email_error','Please Try Again');
					redirect('home/signUp');
				}
			}
		}

	else
	{

	$this->load->view('include/header');
	$this->load->view('auth/signup');
	$this->load->view('include/footer');
    }
	
}
public function sendMessage(){
	print_r($_POST);
	$this->load->view('include/footer');
}


}

?>