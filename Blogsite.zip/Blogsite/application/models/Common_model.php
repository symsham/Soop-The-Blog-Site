<?php
class Common_model extends CI_model 
{
	public function __construct(){
		parent::__construct();

	}
    public function select_data($table,$field,$warr=''){
    	if($warr!='')
    	{
    	$this->db->where($warr);
    }
    $resp=$this->db->select($field)->from($table)->get()->result_array();
    return $resp; 
    }

    public function insert_data($table,$data) {
       return ($this->db->insert($table ,$data));

    }
    public function delete_data($table,$data){
      $this->db->where($data);
      $this->db->delete($table);
   }
   public function update_data($table,$data,$warr){
      $this->db->where($warr);
      return $this->db->update($table,$data);
   }
public function likeQuery($table,$warr){
   $this->db->like($warr);
   return $this->db->from($table)->get()->result_array();
}


}





?>
