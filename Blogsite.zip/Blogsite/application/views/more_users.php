<div class="container body_secton">
 <div class="container-fluid">
 	<div class="row">
	  	<div class="col-sm-10">
	  		<br>
	  		<div class="form-group">
	  			<br>
	  			<h1>Follow Users</h1>
	  		</div>
	  			
	 	 <?php foreach($users as $user) { 

	 	if($user['id']!=$this->session->userdata('userinfo')[0]['id']) {
	 	?>
	 <div class="row profileBlock mb-2">
	  			<div class="col-sm-3">
	  				<i class="fa fa-user-circle-o" aria-hidden="true" style="font-size: 100px;"></i>
	  			</div>
	  			<div class="col-sm-9">
	  				<p><?php echo $user['name'] ?></p>
	  				<p><i class="fa fa-map-marker" aria-hidden="true"></i>  <?php if($user['city']!='') { ?>(<?php echo $user['city'] ?>) <?php } else { echo "N/A"; } 

				$state = $this->CM->select_data('follow_user','status',array('user1'=>$user['id'],'user2'=>$this->session->userdata('userinfo')[0]['id']));
	  					if($state) {
	  						$text = 'Requested';
	  						if($state[0]['status']==1) {
	  							$text='Approved';
	  						}
	  				?> <button class="float-right btn btn-primary btn-sm"><?php echo $text ?></button>
	  				<?php } else {
	  					?>
	  					<a href="<?php echo base_url('home/follow_user/'.$user['id']) ?>" class="float-right btn btn-info btn-sm">Follow</a>
	  					<?php
	  				}  ?></p>
	  			</div>
	  		</div>	
	  	<?php } } ?>
	  		
  </div>
</div>