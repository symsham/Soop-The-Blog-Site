<div class="container body-section" >
<div class="container-fluid">
<div class="row mt-2 login-container">
	<div class="col-sm-4"></div>
<div class="col-sm-4">
	<div class="form-group">
	<div class="form-group text-center">
		<h4>Sign Up</h4>
		<?php if($this->session->flashdata('email_error')) { ?>
	  			<div class="alert alert-primary" role="alert">
				  <?php echo $this->session->flashdata('email_error'); ?>
				</div>
			<?php } ?>
	  		</div>
	<form action="<?php echo base_url(). 'home/signup' ?>" method="post">
<div class="form-group">
	<label>Name</label>
	<input type="text" required="required" class="form-control" name="name" placeholder="Enter Username">
</div>
<div class="form-group">
	<label>Email</label>
	<input type="email" required="required" class="form-control" name="email" placeholder="Enter Email">
</div>
<div class="form-group">
	  			<label>Mobile No</label>
	  			<input type="text" required="required" name="mobile_no" class="form-control" placeholder="Enter Mobile No">
	  		</div>
<div class="form-group">
	<label>Password</label>
	<input type="password" required="required" class="form-control" name="password" placeholder="Enter Password">
</div>
<div class="form-group mb-2">
	<button type="submit" class="btn btn-info btn-block">SignUp</button>
</div>
</form>
<div class="form-group mb-2 text-center">
	OR
</div>
<div class="form-group mb-2">
	<a href="<?php echo base_url("home/login") ?>" class="btn btn-primary btn-block">Already have an account??Login</a>
	
</div>
</div>
</div>
</div>
</div>
</div>