<div class="contriner body_secton">
 <div class="container-fluid">
 	<div class="row mt-4 login-container">
 		<div class="col-sm-4"></div>
	  	<div class="col-sm-4">
	  		<div class="form-group text-center">
	  			<h4>Login</h4>
				  <?php if($this->session->flashdata('success')) { ?>
					<div class="alert alert-success" role="alert">
					<?php echo $this->session->flashdata('success'); ?>
					</div>
				<?php }  if($this->session->flashdata('email_error')) { ?>
					<div class="alert alert-danger" role="alert">
					<?php echo $this->session->flashdata('email_error'); ?>
					</div>
				<?php }
				?>
	  		</div>
	  		<form action="<?php echo base_url().'home/login' ?>" method="post">
	  		<div class="form-group">
	  			<label>Username</label>
	  			<input type="email" required="required" name="name" class="form-control" placeholder="Enter Username">
	  		</div>
	  		<div class="form-group">
	  			<label>Password</label>
	  			<input type="password" class="form-control" required="required" name="password" placeholder="Enter Password">
	  		</div>
	  		<div class="form-group mb-2">
	  			<button class="btn btn-info btn-block">Login</button>
	  		</div>
	  		</form>
	  		<div class="form-group mb-2 text-center">
	  			OR
	  		</div>
	  		<div class="form-group mb-2">
	  			<a href="<?php echo base_url('home/signUp') ?>" class="btn btn-primary btn-block">Create New Account</a>
	  		</div>
	  	</div>
	 </div>
  </div>
</div>