
<div class="container mt-3">

<div class="messaging mt-4">
      <div class="inbox_msg">
        <div class="inbox_people">
          <div class="headind_srch">
            <div class="recent_heading">
              <h4>Recent</h4>
            </div>
            <div class="srch_bar">
              <div class="stylish-input-group">
                <input type="text" class="search-bar"  placeholder="Search" >
                <span class="input-group-addon">
                <button type="button"> <i class="fa fa-search" aria-hidden="true"></i> </button>
                </span> </div>
            </div>
          </div>
          <div class="inbox_chat">
            <?php foreach($chatToken as $token){ ?>
            <div class="chat_list active_chat" data-user="<?php echo $token['user_id'] ?>" data-user2="<?php echo $token['user_id2'] ?>" data-token="<?php echo $token['token'] ?>">
              
              <div class="chat_people">
                <div class="chat_img"> <i class="fa fa-user-circle-o" aria-hidden="true" style="font-size: 50px;"></i></div>
                <div class="chat_ib">
                  <h5> <?php echo $token['username'] ?></h5>
                  <p>Hi!!!! Welcome to message</p>
                </div>
              </div>
              <?php }?>
            </div>
            
          </div>
        </div>
        <div class="mesgs" id='welcomeBox'>
          <div class="msg_history userinfoBox">

            <h2>Welcome to Message</h2>
            <h3><?php print_r($this->session->userdata('userinfo')[0]['name']) ?></h3>
            </div>
            
          </div>
        <div class="mesgs hide" id="messageBox">
          <div class="msg_history">
            <div class="incoming_msg">
              <div class="incoming_msg_img"> <img src="https://ptetutorials.com/images/user-profile.png" alt="sunil"> </div>
              <div class="received_msg">
                <div class="received_withd_msg">
                  <p>Test which is a new approach to have all
                    solutions</p>
                  <span class="time_date"> 11:01 AM    |    June 9</span></div>
              </div>
            </div>
            <div class="outgoing_msg">
              <div class="sent_msg">
                <p>Test which is a new approach to have all
                  solutions</p>
                <span class="time_date"> 11:01 AM    |    June 9</span> </div>
            </div>
            <div class="incoming_msg">
              <div class="incoming_msg_img"> <img src="https://ptetutorials.com/images/user-profile.png" alt="sunil"> </div>
              <div class="received_msg">
                <div class="received_withd_msg">
                  <p>Test, which is a new approach to have</p>
                  <span class="time_date"> 11:01 AM    |    Yesterday</span></div>
              </div>
            </div>
            <div class="outgoing_msg">
              <div class="sent_msg">
                <p>Apollo University, Delhi, India Test</p>
                <span class="time_date"> 11:01 AM    |    Today</span> </div>
            </div>
            <div class="incoming_msg">
              <div class="incoming_msg_img"> <img src="https://ptetutorials.com/images/user-profile.png" alt="sunil"> </div>
              <div class="received_msg">
                <div class="received_withd_msg">
                  <p>We work directly with our designers and suppliers,
                    and sell direct to you, which means quality, exclusive
                    products, at a price anyone can afford.</p>
                  <span class="time_date"> 11:01 AM    |    Today</span></div>
              </div>
            </div>
          </div>
          <div class="type_msg">
            <input type="hidden" name="token" id="token"/>
            <input type="hidden" name="user" id="user"/>
            <input type="hidden" name="user2" id="user2"/>
            <div class="input_msg_write">
              <input type="text" class="write_msg" id="message" placeholder="Type a message" />
              
              <button class="msg_send_btn" id="sendmessage" type="button"><i class="fa fa-paper-plane-o" aria-hidden="true"></i></button>
            </div>
          </div>
        </div>
      </div>
      
      
     
      
    </div></div>
    