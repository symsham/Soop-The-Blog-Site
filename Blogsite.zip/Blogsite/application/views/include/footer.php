<script src="<?php echo base_url().'tools/js/jquery-3.6.3.min.js'?>"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="<?php echo base_url().'tools/js/bootstrap.js'?>"></script>
<script src="<?php echo base_url().'tools/js/custom.js' ?>"></script>
</body>
</html>