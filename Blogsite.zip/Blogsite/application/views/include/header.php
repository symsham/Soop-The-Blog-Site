<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Home</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url().'tools/css/bootstrap.css' ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url().'tools/font-awesome/css/font-awesome.css' ?>">
	<link rel="stylesheet"  href="<?php echo base_url().'tools/css/style.css' ?>">
	<script type="text/javascript">
    var base_url = "<?php echo base_url() ?>";
  </script>
</head>
<body >
	<nav class="navbar navbar-expand-sm bg-dark navbar-dark fixed-top">
  <a class="navbar-brand" href="#">SOOP~MyBlog</a>
  <ul class="navbar-nav menubar">
    <li class="nav-item active">
      <a class="nav-link" title="Home" href="<?php echo base_url()?>"><i class="fa fa-home" aria-hidden="true"></i></a>
    </li>
    <li class="nav-item">
      <a class="nav-link" title="Chat" href="<?php echo base_url('home/chat')?>"><i class="fa fa-commenting" aria-hidden="true"></i></a>
    </li>
    <li class="nav-item">
      <a class="nav-link" title="Notification" href="<?php echo base_url('home/notify')?>"><i class="fa fa-bell-o" aria-hidden="true"></i></a>
  </li>
  <li class="nav-item">
      <a class="nav-link" title="Follow Request" href="<?php echo base_url('home/follow_request') ?>"><i class="fa fa-user" aria-hidden="true"></i></a>
  </li>
  </ul>
</nav>
