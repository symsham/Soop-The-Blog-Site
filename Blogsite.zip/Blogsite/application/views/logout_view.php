<html>
<head>
    <title>Logout</title>
</head>
<body>
    <h1>Logout Successful</h1>
    <p>You have been logged out.</p>
</body>
</html>