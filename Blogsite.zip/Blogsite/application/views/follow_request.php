	<div class="container body_secton">
 <div class="container-fluid">
<?php foreach((array)$follow_users as $user) { ?>
	 <div class="row profileBlock  mt-5">
	  			<div class="col-sm-3">
	  				<i class="fa fa-user-circle-o" aria-hidden="true" style="font-size: 100px;"></i>
	  			</div>
	  			<div class="col-sm-9">
	  				<p><?php echo $user['name'] ?></p>
	  				<p><i class="fa fa-map-marker" aria-hidden="true"></i> <?php if($user['city']!='') {  ?> (<?php echo $user['city'] ?>) <?php } else { echo "N/A"; } 
	  				if($user['status']==1) {
	  					?>
	  					<button class="btn btn-primary float-right btn-sm">Approved</button>
	  					<?php
	  				} else {
	  					?>
	  					<a class="btn btn-danger btn-sm float-right" href="<?php echo base_url('home/delete_request/'.$user['id']) ?>">Delete Request</a>
	  					<a href="<?php echo base_url('home/approve_request/'.$user['id']) ?>" class="float-right btn btn-info btn-sm mr-2">Approve</a>
	  					<?php 
	  				}
	  				?> 

	  				
	  			</div>
	  		</div>
	  	<?php } ?>
  </div>
</div>