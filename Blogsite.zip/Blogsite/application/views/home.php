<div class="contriner body_secton">
 <div class="container-fluid">
 	<div class="row">
	  	<div class="col-sm-8">
	  		<div class="container">
	  			<?php 
	  			if($this->session->userdata('userinfo')) {
	  			?>
	  			<form action="<?php echo base_url('home/createNewPost') ?>" method="post">
	  			<div class="row mt-4 mb-4">
	  				<div class="col-sm-12 pt-2 pb-2">
	  					<h4>Create New Post</h4>
	  				</div>
	  				<div class="col-sm-9 mr-2">
	  					<textarea name="text_post" class="form-control" placeholder="Enter Your Post"></textarea>
	  				</div>
	  				
	  				<div class="col-sm-12">
	  					<input type="submit" name="post_btn" class="btn btn-info btn-block mt-2" value="Post">
	  				</div>
	  			</div>
	  			</form>
	  		<?php } else {
	  			?>
	  			<p class="text-success mt-2 mb-2">Create A New Post . Please Login First <a href="<?php echo base_url('home/login') ?>" class="text-primary">Click Here Login</a></p>
	  			<?php 
	  		}
	  		if($this->session->flashdata('success_message')) { ?>
					<div class="alert alert-success" role="alert">
					<?php echo $this->session->flashdata('success_message'); ?>
					</div>
				<?php }
				?>
	  			<div class="row">
	  			<?php 
	  			foreach($post as $singlePost) {
	  			?>
	  				<div class="col-sm-12 post_block">
	  					<div class="username_block">
	  						<p><i class="fa fa-user"></i> <?php echo $singlePost['username'];
	  						if($singlePost['status']==1) {
	  							$user_info = $this->CM->select_data('users','name',array('id'=>$singlePost['parent_user']));
	  							echo "<span class='text-info ml-2'>Shared Post ".$user_info[0]['name']."</span>";
	  						}
	  						?></p>
	  					</div>
	  					<div class="publish_date text-right">
	  						<p> <?php echo date('d/m/Y h:i A',strtotime($singlePost['created_at'])) ?></p>
	  					</div>
	  					<p><?php echo $singlePost['text_post']; ?></p>
	  					<div class="post_footer text-right">
	  					<?php if($this->session->userdata('userinfo')) { 
	  						$isLike = $this->CM->select_data('post_like','id',array('post_id'=>$singlePost['id'],'user_id'=>$this->session->userdata('userinfo')[0]['id']));
	  						if(count($isLike)>0) {
	  						?>
	  						
	  						<a href="<?php echo base_url('home/post_like/'.$this->session->userdata('userinfo')[0]['id']).'/'.$singlePost['id'] ?>" class="mr-2"><i class="fa fa-thumbs-up"></i></a>
	  						<?php } else { ?>
	  						<a href="<?php echo base_url('home/post_like/'.$this->session->userdata('userinfo')[0]['id']).'/'.$singlePost['id'] ?>" class="mr-2"><i class="fa fa-thumbs-o-up"></i></a>	
	  						<?php } 
	  						$this->db->join('users','post_comment.user_id=users.id');
	  						$this->db->order_by('post_comment.id','desc');
	  						$postComment = $this->CM->select_data('post_comment','post_comment.*,users.name as username',array('post_comment.post_id'=>$singlePost['id']));
	  						?>
	  						<a href="javascript:;" data-comment='<?php echo json_encode($postComment); ?>' data-user="<?php echo $this->session->userdata('userinfo')[0]['id'] ?>" data-post="<?php echo $singlePost['id'] ?>" class="mr-2 createComment"><i class="fa fa-comment"></i></a>
	  						<a href="<?php echo base_url('home/share_post/'.$singlePost['id']) ?>" class="mr-2"><i class="fa fa-share"></i></a>
	  					<?php } ?>
	  					</div>
	  				</div>
	  			<?php 
	  		    }
	  			?>
	  			</div>
	  		</div>
	  	</div>
	  	<?php if($this->session->userdata('userinfo')) { ?>
	  	<div class="col-sm-4">
	  		<div class="row">
	  			<div class="col-sm-12 mb-2 mt-5">
	  				<form action="<?php echo base_url('home/search_result') ?>" method="post">
	  				<div class="form-group">
	  					<br>
	  					<input type="text" placeholder="Search..." name="search" class="form-control" >
	  				</div>
	  				<div class="form-group">
	  					<input type="submit" value="Search" class="btn btn-info btn-block">
	  				</div>
	  			</form>
	  			</div>
	  		</div>
	  		
	  		
	  		<div class="row">
	  			<div class="col-sm-12">
	  				<div class="col-sm-12 mb-2 mt-2">
	  				<a href="<?php echo base_url().'home/more_users' ?>" class="btn btn-info btn-block">Follow the Users </a>
	  			</div>
	  		</div>
	  	</div>
	  			</form>
	  			<div class="col-sm-12">
	  		<form action="<?php echo base_url('home/logout_view') ?>" >
	  				<div class="form-group">
	  					<input type="submit" value="Logout" class="btn btn-info btn-block">
	  				</div>
	  			</form>
	  			<?php } ?>
	  		<p></p>
	  	</div>
     </div>
 </div>
</div>
	  				
	  			</div>
	  		</div>
<div class="modal fade" id="commentPopup" role="dialog">
<div class="modal-dialog">

  <!-- Modal content-->
  <div class="modal-content">
    <div class="modal-header">
      <h4 class="modal-title">Post Comment's</h4>
      <button type="button" class="close" data-dismiss="modal">&times;</button>
    </div>
    <div class="modal-body">
      <div class="row">
      	<div class="col-sm-12">
      		<div class="form-group">
      			<label>Enter Comment</label>
      			<input type="hidden" name="user_id" id="user_id">
      			<input type="hidden" name="post_id" id="post_id">
      			<textarea class="form-control" id="commentField" placeholder="Enter Comment Here"></textarea>
      		</div>
      	</div>
      	<div class="col-sm-12">
      		<div class="form-group">
      			<button id="submitComment" class="btn btn-info btn-sm">Create Comment</button>
      		</div>
      	</div>
      </div>
      <hr />
      <div class="showComment">
      	
      </div>
    </div>
  </div>
  
</div>
</div>	