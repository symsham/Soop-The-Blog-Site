<div class="notify mt-4" >
<h1>Sorry this page is not working properly</h1>
<h2>We will be back to you soon!!!</h2>
</div>